import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class InsertStudentAttendance extends Frame 
{
	Button insertStudentAttendanceButton;
	TextField t_idText, s_idText, subjectText, dayText,  statusText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	public InsertStudentAttendance() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","akhila","vasavi");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	public void buildGUI() 
	{		
		//Handle Insert Account Button
		insertStudentAttendanceButton = new Button("Insert StudentAttendance");
		insertStudentAttendanceButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
				  //String query = "INSERT INTO sailors (SID,SNAME, RATING, AGE) VALUES (2,'Divya',7,20)";				  
				  String query= "INSERT INTO student_attendance VALUES('" + t_idText.getText() + "','"+ s_idText.getText() + "', " + "'" + subjectText.getText() +"','"+ dayText.getText()+  "','" + statusText.getText() + "')";
				  int i = statement.executeUpdate(query);
				  errorText.append("\nInserted " + i + " rows successfully");
				} 
				catch (SQLException insertException) 
				{
				  displaySQLErrors(insertException);
				}
			}
		});

		t_idText = new TextField(15);
		s_idText = new TextField(15);
		subjectText = new TextField(15);
		dayText = new TextField(15);
		statusText = new TextField(15);
		

		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(5, 2));
		first.add(new Label("Teacher ID:"));
		first.add(t_idText);
		first.add(new Label("Student ID:"));
		first.add(s_idText);
		first.add(new Label("Subject:"));
		first.add(subjectText);
		first.add(new Label("Day:"));
		first.add(dayText);
		first.add(new Label("Status:"));
		first.add(statusText);
		first.setBounds(125,40,200,170);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(insertStudentAttendanceButton);
        second.setBounds(125,220,150,100);         
		
		Panel third = new Panel();
		third.add(errorText);
		third.setBounds(125,320,300,200);
		
		setLayout(null);

		add(first);
		add(second);
		add(third);
	    
		setTitle("New Student Attendance Creation");
		setSize(500, 600);
		setVisible(true);
	}

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		InsertStudentAttendance sa = new InsertStudentAttendance();

		sa.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		sa.buildGUI();
	}
}

