import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class UpdateTeaches extends Frame 
{
	Button updateTeachesButton;
	List TeachesIDList;
	TextField T_IDText,           
	S_IDText,   
	SUBJECTText;         
	
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public UpdateTeaches() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","akhila","vasavi");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadTeaches() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT T_ID FROM Teaches");
		  while (rs.next()) 
		  {
			TeachesIDList.add(rs.getString("T_ID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	   TeachesIDList = new List(10);
		loadTeaches();
		add(TeachesIDList);
		
		//When a list item is selected populate the text fields
		TeachesIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM Teaches where T_ID ='"+TeachesIDList.getSelectedItem()+"'");
					rs.next();
					T_IDText.setText(rs.getString("T_ID"));             
					S_IDText.setText(rs.getString("S_ID"));   
					SUBJECTText.setText(rs.getString("SUBJECT")); 
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Update Sailor Button
		updateTeachesButton = new Button("Update Teaches");
		updateTeachesButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE Teaches "
					+ "SET S_ID='" +S_IDText.getText() + "', "
					
											+ "SUBJECT='" + SUBJECTText.getText()  + "' WHERE T_ID =' "
					+ TeachesIDList.getSelectedItem()+"'");
					errorText.append("\nUpdated " + i + " rows successfully");
					TeachesIDList.removeAll();
					loadTeaches();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		T_IDText = new TextField(15);
		T_IDText.setEditable(false);
		S_IDText = new TextField(15);
		S_IDText.setEditable(false);   
		SUBJECTText = new TextField(15); 
		
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(3, 2));
		first.add(new Label("Teacher ID:"));
		first.add(T_IDText);
		first.add(new Label("Student ID:"));
		first.add(S_IDText);
		first.add(new Label("subject:"));
		first.add(SUBJECTText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(updateTeachesButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setTitle("Update Teaches");
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	public static void main(String[] args) 
	{
		UpdateTeaches upq = new UpdateTeaches();

		upq.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		upq.buildGUI();
	}
}

