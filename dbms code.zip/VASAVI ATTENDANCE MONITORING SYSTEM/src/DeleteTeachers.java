import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class DeleteTeachers extends Frame 
{
	Button deleteTeachersButton;
	List TeachersIDList;
	TextField T_IDText,           
	T_NAMEText,          
	T_EMAILText,        
	T_PHNOText,
	T_PWText,   
	SUBJECTText;         
	
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public DeleteTeachers() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","akhila","vasavi");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadTeachers() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM Teachers");
		  while (rs.next()) 
		  {
			TeachersIDList.add(rs.getString("T_ID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    TeachersIDList = new List(10);
		loadTeachers();
		add(TeachersIDList);
		
		//When a list item is selected populate the text fields
		TeachersIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM Teachers");
					while (rs.next()) 
					{
						if (rs.getString("T_ID").equals(TeachersIDList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{        
						T_IDText.setText(rs.getString("T_ID"));             
						T_NAMEText.setText(rs.getString("T__NAME"));           
						T_EMAILText.setText(rs.getString("T_EMAIL"));         
						T_PHNOText.setText(rs.getString("T_PHNO")); 
						T_PWText.setText(rs.getString("T_PW"));    
						SUBJECTText.setText(rs.getString("SUBJECT")); 
				} }
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Delete Sailor Button
		deleteTeachersButton = new Button("Delete Teachers");
		deleteTeachersButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM Teachers WHERE T_ID = '"
							+ TeachersIDList.getSelectedItem()+"'");
					errorText.append("\nDeleted " + i + " rows successfully");
					
					     
					T_IDText.setText(null);             
					T_NAMEText.setText(null);            
					T_EMAILText.setText(null);          
					T_PHNOText.setText(null);  
					T_PWText.setText(null);    
					SUBJECTText.setText(null);  
					TeachersIDList.removeAll();
					loadTeachers();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		
		     
		T_IDText = new TextField(15);              
		T_NAMEText = new TextField(15);           
		T_EMAILText = new TextField(15);         
		T_PHNOText = new TextField(15); 
		T_PWText = new TextField(15);    
		SUBJECTText = new TextField(15); 
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(6, 2));
		first.add(new Label("Teacher ID:"));
		first.add(T_IDText);
		first.add(new Label("Name:"));
		first.add(T_NAMEText);
		first.add(new Label("email:"));
		first.add(T_EMAILText);
		first.add(new Label("phno:"));
		first.add(T_PHNOText);
		first.add(new Label("pw:"));
		first.add(T_PWText);
		first.add(new Label("subject:"));
		first.add(SUBJECTText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(deleteTeachersButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setTitle("Remove Teachers");
		setSize(450, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		DeleteTeachers delt = new DeleteTeachers();
		delt.addWindowListener(new WindowAdapter(){
			  public void windowClosing(WindowEvent e) 
			  {
				System.exit(0);
			  }
			});
			
			delt.buildGUI();
		}
	}

