import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class InsertTeachers extends Frame 
{
	Button insertTeachersButton;
	TextField t_idText, t_nameText,  t_emailText, t_phnoText, t_pwText, subjectText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	public InsertTeachers() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","akhila","vasavi");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	public void buildGUI() 
	{		
		//Handle Insert Account Button
		insertTeachersButton = new Button("Insert Teachers");
		insertTeachersButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
				  //String query = "INSERT INTO sailors (SID,SNAME, RATING, AGE) VALUES (2,'Divya',7,20)";				  
				  String query= "INSERT INTO teachers VALUES('" + t_idText.getText() + "', "  +"'"+ t_nameText.getText() + "'," + "'"+ t_emailText.getText() + "'," + t_phnoText.getText() +   ",'" + t_pwText.getText() + "','" + subjectText.getText() + "')";
				  int i = statement.executeUpdate(query);
				  errorText.append("\nInserted " + i + " rows successfully");
				} 
				catch (SQLException insertException) 
				{
				  displaySQLErrors(insertException);
				}
			}
		});

	
		t_idText = new TextField(15);
		t_nameText = new TextField(15);
		t_emailText = new TextField(15);
		t_phnoText = new TextField(15);
		t_pwText = new TextField(15);
		subjectText = new TextField(15);
		

		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(6, 2));
		first.add(new Label("Teacher ID:"));
		first.add(t_idText);
		first.add(new Label("Name:"));
		first.add(t_nameText);
		first.add(new Label("Email:"));
		first.add(t_emailText);
		first.add(new Label("Phno.:"));
		first.add(t_phnoText);
		first.add(new Label("Password:"));
		first.add(t_pwText);
		first.add(new Label("Subject:"));
		first.add(subjectText);
		first.setBounds(125,40,200,170);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(insertTeachersButton);
        second.setBounds(125,220,150,100);         
		
		Panel third = new Panel();
		third.add(errorText);
		third.setBounds(125,320,400,200);
		
		setLayout(null);

		add(first);
		add(second);
		add(third);
	    
		setTitle("New Teachers Creation");
		setSize(500, 600);
		setVisible(true);
	}

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		InsertTeachers t = new InsertTeachers();

		t.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		t.buildGUI();
	}

}
