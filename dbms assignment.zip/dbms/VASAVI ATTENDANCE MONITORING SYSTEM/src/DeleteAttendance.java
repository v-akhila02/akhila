import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class DeleteAttendance extends Frame 
{
	Button deleteAttendanceButton;
	List AttendanceIDList;
	TextField S_IDText,           
	S_NAMEText,          
	SUBJECTText,          
	DAYText,
	COURSEText,    
	SEMText,  
	YEARText,
	STATUSText;        
	
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public DeleteAttendance() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","akhila","vasavi");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadAttendance() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM Attendance");
		  while (rs.next()) 
		  {
			AttendanceIDList.add(rs.getString("s_ID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    AttendanceIDList = new List(10);
		loadAttendance();
		add(AttendanceIDList);
		
		//When a list item is selected populate the text fields
		AttendanceIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM Attendance");
					while (rs.next()) 
					{
						if (rs.getString("S_ID").equals(AttendanceIDList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{        
						             
						S_IDText.setText(rs.getString("S_ID"));               
						S_NAMEText.setText(rs.getString("S_NAME"));              
						SUBJECTText.setText(rs.getString("SUBJECT"));              
						DAYText.setText(rs.getString("DAY"));    
						COURSEText.setText(rs.getString("COURSE"));        
						SEMText.setText(rs.getString("SEM"));     
						YEARText.setText(rs.getString("YEAR"));    
						STATUSText.setText(rs.getString("STATUS"));    
				} }
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Delete Sailor Button
		deleteAttendanceButton = new Button("Delete Attendance");
		deleteAttendanceButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM Attendance WHERE S_ID = "
							+ AttendanceIDList.getSelectedItem());
					errorText.append("\nDeleted " + i + " rows successfully");
					
					                 
					S_IDText.setText(null);           
					S_NAMEText.setText(null);           
					SUBJECTText.setText(null);          
					DAYText.setText(null); 
					COURSEText.setText(null);      
					SEMText.setText(null);   
					YEARText.setText(null); 
					STATUSText.setText(null);  
					AttendanceIDList.removeAll();
					loadAttendance();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		
		     
		          
		S_IDText = new TextField(15);             
		S_NAMEText = new TextField(15);             
		SUBJECTText = new TextField(15);             
		DAYText = new TextField(15);   
		COURSEText = new TextField(15);        
		SEMText = new TextField(15);    
		YEARText = new TextField(15);   
		STATUSText = new TextField(15);   
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Student ID:"));
		first.add(S_IDText);
		first.add(new Label("Name:"));
		first.add(S_NAMEText);
		first.add(new Label("Subject:"));
		first.add(SUBJECTText);
		first.add(new Label("day:"));
		first.add(DAYText);
		first.add(new Label("course:"));
		first.add(COURSEText);
		first.add(new Label("sem:"));
		first.add(SEMText);
		first.add(new Label("year:"));
		first.add(YEARText);
		first.add(new Label("status:"));
		first.add(STATUSText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(deleteAttendanceButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setTitle("Remove Attendance");
		setSize(450, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		DeleteAttendance dela = new DeleteAttendance();
		dela.addWindowListener(new WindowAdapter(){
			  public void windowClosing(WindowEvent e) 
			  {
				System.exit(0);
			  }
			});
			
			dela.buildGUI();
		}
	}

