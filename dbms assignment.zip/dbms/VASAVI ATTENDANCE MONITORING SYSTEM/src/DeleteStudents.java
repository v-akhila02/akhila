import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class DeleteStudents extends Frame 
{
	Button deleteStudentsButton;
	List StudentsIDList;
	TextField S_IDText,          
	S_NAMEText,  
	S_FNAMEText,
	S_EMAILText,   
	S_PHNOText,
	COURSEText,    
	DOBText,      
	GENDERText,     
	YEARText,
	SEMText,
	S_PWText,
	BRANCHText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public DeleteStudents() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","akhila","vasavi");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadStudents() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM Students");
		  while (rs.next()) 
		  {
			StudentsIDList.add(rs.getString("S_ID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    StudentsIDList = new List(10);
		loadStudents();
		add(StudentsIDList);
		
		//When a list item is selected populate the text fields
		StudentsIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM Students");
					while (rs.next()) 
					{
						if (rs.getString("S_ID").equals(StudentsIDList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						S_IDText.setText(rs.getString("S_ID"));          
						S_NAMEText.setText(rs.getString("S_NAME"));   
						S_FNAMEText.setText(rs.getString("S_FNAME")); 
						S_EMAILText.setText(rs.getString("S_EMAIL"));     
						S_PHNOText.setText(rs.getString("S_PHNO"));
						COURSEText.setText(rs.getString("COURSE"));    
						DOBText.setText(rs.getString("DOB"));      
						GENDERText.setText(rs.getString("GENDER"));     
						YEARText.setText(rs.getString("YEAR")); 
						SEMText.setText(rs.getString("SEM")); 
						S_PWText.setText(rs.getString("S_PW"));  
						BRANCHText.setText(rs.getString("BRANCH")); 
				} }
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Delete Sailor Button
		deleteStudentsButton = new Button("Delete Students");
		deleteStudentsButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM Students WHERE S_ID = "
							+ StudentsIDList.getSelectedItem());
					errorText.append("\nDeleted " + i + " rows successfully");
					
					S_IDText.setText(null);          
					S_NAMEText.setText(null);  
					S_FNAMEText.setText(null);
					S_EMAILText.setText(null);        
					S_PHNOText.setText(null); 
					COURSEText.setText(null);    
					DOBText.setText(null);     
					GENDERText.setText(null);     
					YEARText.setText(null);
					SEMText.setText(null);
					S_PWText.setText(null); 
					BRANCHText.setText(null);
					StudentsIDList.removeAll();
					loadStudents();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		
		S_IDText = new TextField(15);          
		S_NAMEText = new TextField(15); 
		S_FNAMEText = new TextField(15); 
		S_EMAILText = new TextField(15);   
		S_PHNOText = new TextField(15); 
		COURSEText  = new TextField(15);   
		DOBText    = new TextField(15); 
		GENDERText = new TextField(15);     
		YEARText = new TextField(15); 
		SEMText = new TextField(15); 
		S_PWText = new TextField(15); 
		BRANCHText = new TextField(15); 
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Student ID:"));
		first.add(S_IDText);
		first.add(new Label("Name:"));
		first.add(S_NAMEText);
		first.add(new Label("Father name:"));
		first.add(S_FNAMEText);
		first.add(new Label("email:"));
		first.add(S_EMAILText);
		first.add(new Label("phno:"));
		first.add(S_PHNOText);
		first.add(new Label("course:"));
		first.add(COURSEText);
		first.add(new Label("dob:"));
		first.add(DOBText);
		first.add(new Label("gender:"));
		first.add(GENDERText);
		first.add(new Label("year:"));
		first.add(YEARText);
		first.add(new Label("sem:"));
		first.add(SEMText);
		first.add(new Label("pw:"));
		first.add(S_PWText);
		first.add(new Label("branch:"));
		first.add(BRANCHText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(deleteStudentsButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setTitle("Remove Students");
		setSize(450, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		DeleteStudents dels = new DeleteStudents();
		dels.addWindowListener(new WindowAdapter(){
			  public void windowClosing(WindowEvent e) 
			  {
				System.exit(0);
			  }
			});
			
			dels.buildGUI();
		}
	}

