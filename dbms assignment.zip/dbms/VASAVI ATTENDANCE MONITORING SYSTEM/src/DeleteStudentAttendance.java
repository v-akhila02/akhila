import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class DeleteStudentAttendance extends Frame 
{
	Button deleteStudentAttendanceButton;
	List StudentAttendanceIDList;
	TextField T_IDText,           
	S_IDText, 
	SUBJECTText,        
	DAYText, 
	STATUSText;      
	
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public DeleteStudentAttendance() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","akhila","vasavi");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadStudentAttendance() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM Student_Attendance");
		  while (rs.next()) 
		  {
			StudentAttendanceIDList.add(rs.getString("s_ID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    StudentAttendanceIDList = new List(10);
		loadStudentAttendance();
		add(StudentAttendanceIDList);
		
		//When a list item is selected populate the text fields
		StudentAttendanceIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM Student_Attendance");
					while (rs.next()) 
					{
						if (rs.getString("S_ID").equals(StudentAttendanceIDList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{        
						                           
						T_IDText.setText(rs.getString("T_ID"));             
						S_IDText.setText(rs.getString("S_ID"));   
						SUBJECTText.setText(rs.getString("SUBJECT"));          
						DAYText.setText(rs.getString("DAY"));  
						STATUSText.setText(rs.getString("STATUS"));        
				} }
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Delete Sailor Button
		deleteStudentAttendanceButton = new Button("Delete StudentAttendance");
		deleteStudentAttendanceButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM Student_Attendance WHERE S_ID = "
							+ StudentAttendanceIDList.getSelectedItem());
					errorText.append("\nDeleted " + i + " rows successfully");
					
					                 
					          
					T_IDText.setText(null);          
					S_IDText.setText(null);
					SUBJECTText.setText(null);       
					DAYText.setText(null);
					STATUSText.setText(null);  
					StudentAttendanceIDList.removeAll();
					loadStudentAttendance();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		
		     
		                      
		T_IDText = new TextField(15);         
		S_IDText = new TextField(15);
		SUBJECTText = new TextField(15);      
		DAYText = new TextField(15);
		STATUSText = new TextField(15);  
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Student ID:"));
		first.add(T_IDText);
		first.add(new Label("TEACHER ID:"));
		first.add(S_IDText);
		first.add(new Label("Subject:"));
		first.add(SUBJECTText);
		first.add(new Label("day:"));
		first.add(DAYText);
		first.add(new Label("status:"));
		first.add(STATUSText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(deleteStudentAttendanceButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setTitle("Remove Student Attendance");
		setSize(450, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		DeleteStudentAttendance delas = new DeleteStudentAttendance();
		delas.addWindowListener(new WindowAdapter(){
			  public void windowClosing(WindowEvent e) 
			  {
				System.exit(0);
			  }
			});
			
			delas.buildGUI();
		}
	}

