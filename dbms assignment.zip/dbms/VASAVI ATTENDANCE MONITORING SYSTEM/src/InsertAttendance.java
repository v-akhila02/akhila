import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class InsertAttendance extends Frame 
{
	Button insertAttendanceButton;
	TextField s_idText, s_nameText, subjectText, dayText, courseText, semText, yearText, statusText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	public InsertAttendance() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","akhila","vasavi");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	public void buildGUI() 
	{		
		//Handle Insert Account Button
		insertAttendanceButton = new Button("Insert Attendance");
		insertAttendanceButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
				  //String query = "INSERT INTO sailors (SID,SNAME, RATING, AGE) VALUES (2,'Divya',7,20)";				  
				  String query= "INSERT INTO attendance VALUES(" + s_idText.getText() + ", " + "'" + s_nameText.getText() +  ", " + "'" + subjectText.getText() +","+ dayText.getText()+","+courseText.getText() +","+ yearText.getText() + ", " + semText.getText() +  "," +statusText.getText() + ")";
				  int i = statement.executeUpdate(query);
				  errorText.append("\nInserted " + i + " rows successfully");
				} 
				catch (SQLException insertException) 
				{
				  displaySQLErrors(insertException);
				}
			}
		});

	
		s_idText = new TextField(15);
		s_nameText = new TextField(15);
		courseText = new TextField(15);
		semText = new TextField(15);
		yearText = new TextField(15);
		statusText = new TextField(15);
		

		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Student ID:"));
		first.add(s_idText);
		first.add(new Label("Name:"));
		first.add(s_nameText);
		first.add(new Label("Subject:"));
		first.add(subjectText);
		first.add(new Label("Day:"));
		first.add(dayText);
		first.add(new Label("Course:"));
		first.add(courseText);
		first.add(new Label("Sem:"));
		first.add(semText);
		first.add(new Label("Year:"));
		first.add(yearText);
		first.add(new Label("Status:"));
		first.add(statusText);
		first.setBounds(125,90,200,100);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(insertAttendanceButton);
        second.setBounds(125,220,150,100);         
		
		Panel third = new Panel();
		third.add(errorText);
		third.setBounds(125,320,300,200);
		
		setLayout(null);

		add(first);
		add(second);
		add(third);
	    
		setTitle("New Attendance Creation");
		setSize(500, 600);
		setVisible(true);
	}

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		InsertAttendance a = new InsertAttendance();

		a.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		a.buildGUI();
	}
}

