import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class InsertStudents extends Frame 
{
	Button insertStudentsButton;
	TextField s_idText, s_nameText, s_fnameText, s_emailText, s_phnoText, courseText, dobText, genderText, yearText, semText, s_pwText, branchText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	public InsertStudents() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","akhila","vasavi");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	public void buildGUI() 
	{		
		//Handle Insert Account Button
		insertStudentsButton = new Button("Insert Students");
		insertStudentsButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
				  //String query = "INSERT INTO sailors (SID,SNAME, RATING, AGE) VALUES (2,'Divya',7,20)";				  
				  String query= "INSERT INTO students VALUES(" + s_idText.getText() + ", " + "'" + s_nameText.getText() + "'," + s_fnameText.getText() + "," + s_emailText.getText() +  s_phnoText.getText() + ", " + "'" + courseText.getText() + "'," + dobText.getText() + "," + genderText.getText() + "," + yearText.getText() + ", " + semText.getText() + "'," + s_pwText.getText() + "," + branchText.getText() + ")";
				  int i = statement.executeUpdate(query);
				  errorText.append("\nInserted " + i + " rows successfully");
				} 
				catch (SQLException insertException) 
				{
				  displaySQLErrors(insertException);
				}
			}
		});

	
		s_idText = new TextField(15);
		s_nameText = new TextField(15);
		s_fnameText = new TextField(15);
		s_emailText = new TextField(15);
		s_phnoText = new TextField(15);
		courseText = new TextField(15);
		dobText = new TextField(15);
		genderText = new TextField(15);
		yearText = new TextField(15);
		semText = new TextField(15);
		s_pwText = new TextField(15);
		branchText = new TextField(15);
		

		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Student ID:"));
		first.add(s_idText);
		first.add(new Label("Name:"));
		first.add(s_nameText);
		first.add(new Label("Father's Name:"));
		first.add(s_fnameText);
		first.add(new Label("Email:"));
		first.add(s_emailText);
		first.add(new Label("Phno.:"));
		first.add(s_phnoText);
		first.add(new Label("Course:"));
		first.add(courseText);
		first.add(new Label("DOB:"));
		first.add(dobText);
		first.add(new Label("Gender:"));
		first.add(genderText);
		first.add(new Label("Year:"));
		first.add(yearText);
		first.add(new Label("Sem:"));
		first.add(semText);
		first.add(new Label("Password:"));
		first.add(s_pwText);
		first.add(new Label("Branch:"));
		first.add(branchText);
		first.setBounds(125,90,200,100);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(insertStudentsButton);
        second.setBounds(125,220,150,100);         
		
		Panel third = new Panel();
		third.add(errorText);
		third.setBounds(125,320,300,200);
		
		setLayout(null);

		add(first);
		add(second);
		add(third);
	    
		setTitle("New Students Creation");
		setSize(500, 600);
		setVisible(true);
	}

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		InsertStudents s = new InsertStudents();

		s.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		s.buildGUI();
	}
}


