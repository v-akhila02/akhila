import java.awt.*; 
import java.awt.event.*; 

class Attendance_Monitoring_System extends Frame implements ActionListener
{ 
	  /**
	 * 
	 */
	//private static final long serialVersionUID = 1L;
	String msg = ""; 
	  Label ll;
	  InsertStudents s;
	  InsertTeachers t;
	  InsertTeaches q;
	  InsertAttendance a;
	  InsertStudentAttendance sa;
	  UpdateStudents ups;
	  UpdateTeachers upt;
	  UpdateTeaches upq;
	  UpdateAttendance upa;
	  UpdateStudentAttendance upsa;
	  DeleteStudents dels;
	  DeleteTeachers delt;
	  DeleteTeaches delq;
	  DeleteAttendance dela;
	  DeleteStudentAttendance delsa;
	  
	  
	  Attendance_Monitoring_System() 
	  { 
			ll = new Label();
			ll.setAlignment(Label.CENTER);  
			ll.setBounds(90,500,500,100); 			
			ll.setText("Welcome to Vasavi Attendance_Monitoring_System");
			add(ll);
		 
			// create menu bar and add it to frame 
			MenuBar mbar = new MenuBar(); 
			setMenuBar(mbar); 
		 
			// create the menu items and add it to Menu
			Menu Student = new Menu("Students"); 
			MenuItem item1, item2, item3; 
			Student.add(item1 = new MenuItem("Insert Students")); 
			Student.add(item2 = new MenuItem("View Students")); 
			Student.add(item3 = new MenuItem("Delete Students")); 
			mbar.add(Student);  
		 
			Menu Teacher = new Menu("Teachers"); 
			MenuItem item4, item5, item6; 
			 Teacher.add(item4 = new MenuItem("Insert Teachers")); 
			 Teacher.add(item5 = new MenuItem("View Teachers")); 
			 Teacher.add(item6 = new MenuItem("Delete Teachers")); 
			mbar.add(Teacher); 
			
			Menu Teaches = new Menu("Teaches"); 
			MenuItem item7, item8, item9; 
			Teaches.add(item7 = new MenuItem("Insert Teaches")); 
			Teaches.add(item8 = new MenuItem("View Teaches")); 
			Teaches.add(item9 = new MenuItem("Delete Teaches")); 
			mbar.add(Teaches); 
			
			Menu Attendance = new Menu("Attendance"); 
			MenuItem item10, item11, item12; 
			 Attendance.add(item10 = new MenuItem("Insert Attendance")); 
			 Attendance.add(item11 = new MenuItem("View Attendance")); 
			 Attendance.add(item12 = new MenuItem("Delete Attendance")); 
			mbar.add(Attendance);
			
			
			
			Menu StudentAttendance = new Menu("StudentAttendance"); 
			MenuItem item13, item14, item15; 
			StudentAttendance.add(item13 = new MenuItem("Insert StudentAttendance")); 
			StudentAttendance.add(item14 = new MenuItem("View StudentAttendance")); 
			StudentAttendance.add(item15 = new MenuItem("Delete StudentAttendance")); 
			mbar.add(StudentAttendance); 
			
			
			
			// register listeners
			item1.addActionListener(this); 
			item2.addActionListener(this); 
			item3.addActionListener(this); 
			item4.addActionListener(this); 
			item5.addActionListener(this); 
			item6.addActionListener(this); 
			item7.addActionListener(this); 
			item8.addActionListener(this); 
			item9.addActionListener(this); 
			item10.addActionListener(this); 
			item11.addActionListener(this); 
			item12.addActionListener(this); 
			item13.addActionListener(this); 
			item14.addActionListener(this); 
			item15.addActionListener(this); 
						
					
			 // Anonymous inner class which extends WindowAdaptor to handle the Window event: windowClosing  
			addWindowListener(new WindowAdapter(){
				public void windowClosing(WindowEvent we) 
				{ 
					System.exit(0);	
				} 
			}); 
			
			//Frame properties
			setTitle("Vasavi Attendance_Monitoring_System"); 
			Color clr = new Color(200, 100, 150);
			setBackground(clr); 
			setFont(new Font("SansSerif", Font.BOLD, 14)); 
			setLayout(null);
			setSize(500, 600); 
			setVisible(true);	
			
	  }   
	  
	  public void actionPerformed(ActionEvent ae) 
	  { 

		  String arg = ae.getActionCommand(); 
		  if(arg.equals("Insert Students"))
		  {
			s = new InsertStudents();

			s.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
			{
				s.dispose();
			}
			});		
			s.buildGUI();	
          }			
		 
		 else if(arg.equals("View Students")) 
		 {
			ups = new UpdateStudents();
			ups.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
		    {
				ups.dispose();
			}
			});		
			ups.buildGUI();		 
		 }
		 
		 
		 else if(arg.equals("Delete Students")) 
		 {
			dels = new DeleteStudents();

			dels.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
			{
				dels.dispose();
			}
			});		
			dels.buildGUI();		 
		 }
		  
		 else if(arg.equals("Insert Teachers"))
		  {
			t = new InsertTeachers();

			t.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
			{
				t.dispose();
			}
			});		
			 t.buildGUI();
         }		
		 
		 else if(arg.equals("Delete Teachers")) 
		 {
			delt = new DeleteTeachers();

			delt.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
			{
				delt.dispose();
			}
			});		
			delt.buildGUI();		 
		 }
		 
		 else if(arg.equals("View Teachers")) 
		 {
			upt = new UpdateTeachers();
			upt.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
		    {
				upt.dispose();
			}
			});		
			upt.buildGUI();		 
		 }
		  
		 else if(arg.equals("Insert Attendance")) 
		 {
			a = new InsertAttendance();
			a.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
		    {
				a.dispose();
			}
			});		
			a.buildGUI();		 
		 }
		 
		 else if(arg.equals("Delete Attendance")) 
		 {
			dela = new DeleteAttendance();

			dela.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
			{
				dela.dispose();
			}
			});		
			dela.buildGUI();		 
		 }
		 
		 else if(arg.equals("View Attendance")) 
		 {
			upa = new UpdateAttendance();
			upa.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
		    {
				upa.dispose();
			}
			});		
			upa.buildGUI();		 
		 }
		  
		 else if(arg.equals("Insert Teaches")) 
		 {
			q = new InsertTeaches();
			q.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
		    {
				s.dispose();
			}
			});		
			s.buildGUI();		 
		 }
		 
		 else if(arg.equals("Delete Teaches")) 
		 {
			delq = new DeleteTeaches();

			delq.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
			{
				delq.dispose();
			}
			});		
			delq.buildGUI();		 
		 }
		 
		 else if(arg.equals("View Teaches")) 
		 {
			upq = new UpdateTeaches();
			upq.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
		    {
				upq.dispose();
			}
			});		
			upq.buildGUI();		 
		 }
		 	
		 else if(arg.equals("Insert StudentAttendance"))
		  {
			sa = new InsertStudentAttendance();

			sa.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
			{
				sa.dispose();
			}
			});		
			sa.buildGUI();	
          }	
		  
		 else if(arg.equals("Delete StudentAttendance")) 
		 {
			delsa = new DeleteStudentAttendance();

			delsa.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
			{
				delsa.dispose();
			}
			});		
			delsa.buildGUI();		 
		 }
		 
		 else if(arg.equals("View StudentAttendance")) 
		 {
			upsa = new UpdateStudentAttendance();
			upsa.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
		    {
				upsa.dispose();
			}
			});		
			upsa.buildGUI();		 
		 }
	  }
	  public static void main(String ... args)
	  {
			new Attendance_Monitoring_System();	  
	  }
} 
 

 

